import React from "react";
import { NavLink } from 'react-router-dom';

// Project


const Navbar = () =>  {
  return <nav> 
    <NavLink id="Logo" to='/'>Charles Ostman</NavLink>
    <NavLink id="sLogo" to='/'><small> Historian of the future </small></NavLink>
    <NavLink id="home" to='/'>Home</NavLink>
    <NavLink id="Content" to='/Content'>Content</NavLink>
    <NavLink id="Mission" to='/Mission'>Mission</NavLink>
    <NavLink id='about' to='/about'>About</NavLink>
    <NavLink id='contact' to='/contact'>Contact</NavLink>
    <NavLink id='more' to='/more'>More</NavLink>
    <div id="loginbg">  <NavLink id='login' to='/login'>Login</NavLink> </div>
  </nav>  ;


}
export default Navbar;