import React, { Component } from 'react';
//  project
class content extends Component {
  render() {
    return (
      <>
      content page
      </>
    );
  }
}
 
export default content;