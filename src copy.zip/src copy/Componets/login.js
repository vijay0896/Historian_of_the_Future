import React, { Component } from 'react';
//  project
class login extends Component {
  render() {
    return (
      <>
      login page
      </>
    );
  }
}
 
export default login;