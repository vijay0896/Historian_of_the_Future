import React, { Component } from 'react';
//  project
class Contact  extends Component {
  render() {
    return (
      <>
      contact page
      </>
    );
  }
}
 
export default Contact;