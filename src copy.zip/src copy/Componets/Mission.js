import React, { Component } from 'react';
//  project
class Mission extends Component {
  render() {
    return (
      <>
      Mission page
      </>
    );
  }
}
 
export default Mission;